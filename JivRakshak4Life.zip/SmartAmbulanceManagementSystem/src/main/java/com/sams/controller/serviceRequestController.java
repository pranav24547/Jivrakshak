package com.sams.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sams.entities.AmbulanceDetails;
import com.sams.entities.AmbulanceDistances;
import com.sams.entities.HospitalDetails;
import com.sams.entities.TripReport;
import com.sams.entities.User;
import com.sams.service.serviceRequestServices;

@RestController
@RequestMapping("/service")
public class serviceRequestController {
	
	@Autowired
	private serviceRequestServices requestServices;
	
	
	@PostMapping("/addUser")
	public String addUser(@RequestBody User user){
		String usermessage = "";

	if(requestServices.checkNumber(user.getPhoneNo())) {
		usermessage = requestServices.updateUser(user); 
	}else {
		usermessage = requestServices.saveUser(user);
	}
  	
	return usermessage;
	}
	
	
	
	@PostMapping("/checkNumber")
	public Boolean checknumber(@RequestBody String PhoneNO )
	{
		Boolean checkNumber = requestServices.checkNumber(PhoneNO);
		return checkNumber;
	}	
	
	@GetMapping("/getDataUser")
	public User getDataUser(@RequestParam String phoneNo) {
		User Data= requestServices.getData(phoneNo);
		return Data;
	}
	
//	@PostMapping("/checkUsername")
//	public Boolean checkUsername(@RequestBody String Username )
//	{
//		Boolean checkUsername = requestServices.checkUsername(Username);
//		return checkUsername;
//	}	
//	
//	@GetMapping("/getDataAmbulance")
//	public User getDataAmbulance(@RequestBody String Username,String password) {
//		User Data= requestServices.getData(phoneNo);
//		return Data;
//	}
//	
//	
	
	@PostMapping("/addAmbulanceDetails")
	public AmbulanceDetails addAmbulanceDetail(@RequestBody AmbulanceDetails ambulanceDetails)
	{
		  
		AmbulanceDetails addAmbulanceDetails = requestServices.addAmbulanceDetails(ambulanceDetails);
		return addAmbulanceDetails;
	}
	
	@GetMapping("/getAmbulanceDetails")
 	public AmbulanceDetails getAmbulanceDetails(@RequestParam int id) {
		return requestServices.getAmbulanceDetails(id);
	}
	
	@PostMapping("/addHospitalDetails")
	public HospitalDetails addHospitalDetail(@RequestBody HospitalDetails hospitalDetails)
	{
		  
		HospitalDetails addHospitalDetails = requestServices.addHospitalDetails(hospitalDetails);
		return addHospitalDetails;
	}
	
	@GetMapping("/getHospitalData")
 	public HospitalDetails getHospitalDetails(@RequestParam int id) {
		return requestServices.getHospitalDetails(id);
	}
	
	@PostMapping("/endTrip")
	public String endTrip(@RequestParam String id)
	{
		String update = requestServices.Endtrip(id);
		return update;
		
	}	
	@PostMapping("/endTripById")
	public String endTripById(@RequestParam int id)
	{
		String update = requestServices.EndTripByTripId(id);
		return update;
		
	}	
}
 