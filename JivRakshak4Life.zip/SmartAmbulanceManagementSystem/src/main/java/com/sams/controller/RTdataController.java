package com.sams.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sams.entities.RTdata;
import com.sams.entities.trafficSignal;
import com.sams.service.RealTimeService;
import com.sams.service.serviceRequestServices;

@RestController
@RequestMapping("/RealTime")
public class RTdataController {
	
	@Autowired
	private RealTimeService realTimeService;
	
	
	
	@PostMapping("/postData")
	public String postData(@RequestBody RTdata RTdata) 
	{
		String Update = realTimeService.setData(RTdata);
		
		return Update;
	}
	
	@PostMapping("/getData")
	public RTdata getData(@RequestParam int id) 
	{
		RTdata Update = realTimeService.getData(id);
		
		return Update;
	}
	
	
	
	
	@PostMapping("/addSignal")
	public String addSignal(@RequestBody trafficSignal signal) 
	{
		String update = realTimeService.addSignal(signal);
		return update;
		
	}
	
	@GetMapping("/getSignalData")
	public trafficSignal getSignalData(@RequestParam int id)
	{
		trafficSignal update= realTimeService.getSignalDetails(id);
		return update;
	}
}
