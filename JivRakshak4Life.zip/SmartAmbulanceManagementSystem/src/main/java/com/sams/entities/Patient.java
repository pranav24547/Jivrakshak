package com.sams.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "service_request")


public class Patient {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int serviceID;
	private String patientName;
	

	private String latitude;
	private String longitude;
	public int getServiceID() {
		return serviceID;
	}
	public void setServiceID(int serviceID) {
		this.serviceID = serviceID;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	public Patient(int serviceID, String patientName, String latitude, String longitude) {
		super();
		this.serviceID = serviceID;
		this.patientName = patientName;
		this.latitude = latitude;
		this.longitude = longitude;
	}
	public Patient() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	
}	