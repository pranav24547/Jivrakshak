package com.sams.entities;

import java.util.List;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
@Entity
@Table(name = "Hospital_details")
public class HospitalDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
    private int hosId;

	private String Username;

	@ManyToMany
	private List<Patient> patients;
	@ManyToMany
	private List<ambulance> ambulances;
	@OneToOne
	private hospital hospital;
	public HospitalDetails(int id, int hosId, String username, List<Patient> patients,
			List<ambulance> ambulances, com.sams.entities.hospital hospital) {
		super();
		this.id = id;
		this.hosId = hosId;
		Username = username;
		
		this.patients = patients;
		this.ambulances = ambulances;
		this.hospital = hospital;
	}
	public HospitalDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getHosId() {
		return hosId;
	}
	public void setHosId(int hosId) {
		this.hosId = hosId;
	}
	public String getUsername() {
		return Username;
	}
	public void setUsername(String username) {
		Username = username;
	}

	
	public List<Patient> getPatients() {
		return patients;
	}
	public void setPatients(List<Patient> patients) {
		this.patients = patients;
	}
	public List<ambulance> getAmbulances() {
		return ambulances;
	}
	public void setAmbulances(List<ambulance> ambulances) {
		this.ambulances = ambulances;
	}
	public hospital getHospital() {
		return hospital;
	}
	public void setHospital(hospital hospital) {
		this.hospital = hospital;
	}
	
	
}
	