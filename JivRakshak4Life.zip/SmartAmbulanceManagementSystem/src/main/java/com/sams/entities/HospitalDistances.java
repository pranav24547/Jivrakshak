package com.sams.entities;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;


public class HospitalDistances implements Comparable<HospitalDistances>{
	
	private float distance;
	private hospital hospital;
	public HospitalDistances() {
		super();
		
	}
	public HospitalDistances(float distance, com.sams.entities.hospital hospital) {
		super();
		this.distance = distance;
		this.hospital = hospital;
	}
	public float getDistance() {
		return distance;
	}
	public void setDistance(float distance) {
		this.distance = distance;
	}
	public hospital getHospital() {
		return hospital;
	}
	public void setHospital(hospital hospital) {
		this.hospital = hospital;
	}
	@Override
	public String toString() {
		return "HospitalDistances [distance=" + distance + ", hospital=" + hospital + "]";
	}
	
	@Override
	public int compareTo(HospitalDistances o) {
		// TODO Auto-generated method stub
		if(this.distance < o.distance) {
			return -1;
		}else if(this.distance > o.distance) {
			return 1;
		}else {
			return 0;
		}
		
	}
	

}
