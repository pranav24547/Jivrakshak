package com.sams.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "vehicle_data")
public class ambulance {
	@Id 
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int id;
	private String regNo;
	private String type;
	private String drivername;
	private String phoneNo;
	private String latitude;
	private String longitude;
	private String temperature;
	private String status;
	

	
	
	public ambulance(int id, String regNo, String type, String drivername, String phoneNo, String latitude,
			String longitude, String temperature,String Status) {
		super();
		this.id = id;
		this.regNo = regNo;
		this.type = type;
		this.drivername = drivername;
		this.phoneNo = phoneNo;
		this.latitude = latitude;
		this.longitude = longitude;
		this.temperature = temperature;
		this.status = Status;
	}



	
	public String getTemperature() {
		return temperature;
	}




	public void setTemperature(String temperature) {
		this.temperature = temperature;
	}


	public void setStatus(String Status) {
		this.status = Status;
	}

	public void setId(int id) {
		this.id = id;
	}




	public ambulance() {
		
	}


	public int getId() {
		return id;
	}

//	public void setId(int id) {
//		this.id = id;
//	}

	public String getRegNo() {
		return regNo;
	}

	public void setRegNo(String regNo) {
		this.regNo = regNo;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDrivername() {
		return drivername;
	}

	public void setDrivername(String drivername) {
		this.drivername = drivername;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}


	public String getLatitude() {
		return latitude;
	}


	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}


	public String getLongitude() {
		return longitude;
	}


	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	public String getStatus() {
		return status;
	}

	@Override
	public String toString() {
		return "ambulance [id=" + id + ", regNo=" + regNo + ", type=" + type + ", drivername=" + drivername
				+ ", phoneNo=" + phoneNo + ", latitude=" + latitude + ", longitude=" + longitude + "]";
	}


	
	
	

}
