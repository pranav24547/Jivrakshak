package com.sams.entities;

public class LocationRequest {
	

	    private Double lati;
	    private Double longi;

	    // Getters and setters
	    public Double getLati() {
	        return lati;
	    }

	    public void setLati(Double lati) {
	        this.lati = lati;
	    }

	    public Double getLongi() {
	        return longi;
	    }

	    public void setLongi(Double longi) {
	        this.longi = longi;
	    }
	}



