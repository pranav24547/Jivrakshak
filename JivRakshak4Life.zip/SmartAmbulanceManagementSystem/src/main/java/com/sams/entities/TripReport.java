package com.sams.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "trip_report")
public class TripReport {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int tripId;	
	private String phoneNo;
	private float HospitalDistances;
	private float AmbulanceDistances;
	private int amb_id;
	@ManyToOne  
	private hospital Hospital;
	@ManyToOne
	private ambulance Ambulance;
	
	private String status;

	public TripReport(int tripId, String phoneNo, float hospitalDistances, float ambulanceDistances, int amb_id,
			hospital hospital, ambulance ambulance, String status) {
		super();
		this.tripId = tripId;
		this.phoneNo = phoneNo;
		HospitalDistances = hospitalDistances;
		AmbulanceDistances = ambulanceDistances;
		this.amb_id = amb_id;
		Hospital = hospital;
		Ambulance = ambulance;
		this.status = status;
	}

	public TripReport() {
	
	}

	public int getTripId() {
		return tripId;
	}

	public void setTripId(int tripId) {
		this.tripId = tripId;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public float getHospitalDistances() {
		return HospitalDistances;
	}

	public void setHospitalDistances(float hospitalDistances) {
		HospitalDistances = hospitalDistances;
	}

	public float getAmbulanceDistances() {
		return AmbulanceDistances;
	}

	public void setAmbulanceDistances(float ambulanceDistances) {
		AmbulanceDistances = ambulanceDistances;
	}

	public float getAmb_id() {
		return amb_id;
	}

	public void setAmb_id(int amb_id) {
		this.amb_id = amb_id;
	}

	public hospital getHospital() {
		return Hospital;
	}

	public void setHospital(hospital hospital) {
		Hospital = hospital;
	}

	public ambulance getAmbulance() {
		return Ambulance;
	}

	public void setAmbulance(ambulance ambulance) {
		Ambulance = ambulance;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	
	
	
	
}