package com.sams.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "hospital_data")
public class hospital {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int hospitalID;
	private String name;
	private String spoc;
	private String mobileNo;
	private String emailId;
	private String address;
	private String latitude;
	private String longitude;
	
	public hospital(int hospitalID, String name, String spoc, String mobileNo, String emailId, String address, String latitude,  String longitude) {
		super();
		this.hospitalID = hospitalID;
		this.name = name;
		this.spoc = spoc;
		this.mobileNo = mobileNo;
		this.emailId = emailId;
		this.address = address;
		this.latitude = latitude;
		this.longitude = longitude;
		
	}

	public hospital() { 
		
	}

	public int getHospitalID() {
		return hospitalID;
	}

	public void setHospitalID(int hospitalID) {
		this.hospitalID = hospitalID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSpoc() {
		return spoc;
	}

	public void setSpoc(String spoc) {
		this.spoc = spoc;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getAddress() {
		return address;
	}
               
	public void setAddress(String address) {
		this.address = address;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	@Override
	public String toString() {
		return "hospital [hospitalID=" + hospitalID + ", name=" + name + ", spoc=" + spoc + ", mobileNo=" + mobileNo
				+ ", emailId=" + emailId + ", address=" + address + ", latitude=" + latitude + ", longitude="
				+ longitude + "]";
	}
	
}
