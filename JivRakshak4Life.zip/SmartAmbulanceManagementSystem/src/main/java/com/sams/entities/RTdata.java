package com.sams.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import jakarta.persistence.Table;

@Entity
@Table(name = "RTdata")
public class RTdata {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int RTID;
	
	private int ambId;
	private String latitude1;
	private String longitude1;
	private String pulseRate;
	private String bloodPressure;
	public int getRTID() {
		return RTID;
	}
	public void setRTID(int rTID) {
		RTID = rTID;
	}
	public int getAmbId() {
		return ambId;
	}
	public void setAmbId(int ambId) {
		this.ambId = ambId;
	}
	public String getLatitude1() {
		return latitude1;
	}
	public void setLatitude1(String latitude1) {
		this.latitude1 = latitude1;
	}
	public String getLongitude1() {
		return longitude1;
	}
	public void setLongitude1(String longitude1) {
		this.longitude1 = longitude1;
	}
	public String getPulseRate() {
		return pulseRate;
	}
	public void setPulseRate(String pulseRate) {
		this.pulseRate = pulseRate;
	}
	public String getBloodPressure() {
		return bloodPressure;
	}
	public void setBloodPressure(String bloodPressure) {
		this.bloodPressure = bloodPressure;
	}
	public RTdata(int rTID, int ambId, String latitude1, String longitude1, String pulseRate, String bloodPressure) {
		super();
		RTID = rTID;
		this.ambId = ambId;
		this.latitude1 = latitude1;
		this.longitude1 = longitude1;
		this.pulseRate = pulseRate;
		this.bloodPressure = bloodPressure;
	}
	public RTdata() {
		super();
		// TODO Auto-generated constructor stub
	}
	
//	
//	@OneToOne
//	private ambulance ambulance;



		
	
}
