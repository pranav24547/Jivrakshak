package com.sams.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "trafficSignal_data")

public class trafficSignal {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String name;
	private String Latitude;
	private String Longitude;
	private boolean lane1;
	private boolean lane2;
	private boolean lane3;
	private boolean lane4;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLatitude() {
		return Latitude;
	}
	public void setLatitude(String latitude) {
		Latitude = latitude;
	}
	public String getLongitude() {
		return Longitude;
	}
	public void setLongitude(String longitude) {
		Longitude = longitude;
	}
	public boolean isLane1() {
		return lane1;
	}
	public void setLane1(boolean lane1) {
		this.lane1 = lane1;
	}
	public boolean isLane2() {
		return lane2;
	}
	public void setLane2(boolean lane2) {
		this.lane2 = lane2;
	}
	public boolean isLane3() {
		return lane3;
	}
	public void setLane3(boolean lane3) {
		this.lane3 = lane3;
	}
	public boolean isLane4() {
		return lane4;
	}
	public void setLane4(boolean lane4) {
		this.lane4 = lane4;
	}
	public trafficSignal(int id, String name, String latitude, String longitude, boolean lane1, boolean lane2,
			boolean lane3, boolean lane4) {
		super();
		this.id = id;
		this.name = name;
		Latitude = latitude;
		Longitude = longitude;
		this.lane1 = lane1;
		this.lane2 = lane2;
		this.lane3 = lane3;
		this.lane4 = lane4;
	}
	public trafficSignal() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	
	
}
