package com.sams.entities;

import java.util.List;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
@Entity
@Table(name = "ambulance_details")
public class AmbulanceDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private int ambId;
	
	private String Username;
	
	
	@ManyToMany
	private List<Patient> patients;
	@ManyToMany
	private List<hospital> hospitals;
	@OneToOne
	private ambulance Ambulance;
	
	
	public AmbulanceDetails(int id, int ambId, String username, List<Patient> patients,
			List<hospital> hospitals, ambulance ambulance) {
		super();
		this.id = id;
		this.ambId = ambId;
		Username = username;
	
		this.patients = patients;
		this.hospitals = hospitals;
		Ambulance = ambulance;
	}


	public AmbulanceDetails() {
		super();
		// TODO Auto-generated constructor stub
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public int getAmbId() {
		return ambId;
	}


	public void setAmbId(int ambId) {
		this.ambId = ambId;
	}


	public String getUsername() {
		return Username;
	}


	public void setUsername(String username) {
		Username = username;
	}




	public List<Patient> getPatients() {
		return patients;
	}


	public void setPatients(List<Patient> patients) {
		this.patients = patients;
	}


	public List<hospital> getHospitals() {
		return hospitals;
	}


	public void setHospitals(List<hospital> hospitals) {
		this.hospitals = hospitals;
	}


	public ambulance getAmbulance() {
		return Ambulance;
	}


	public void setAmbulance(ambulance ambulance) {
		Ambulance = ambulance;
	}
	
	
	
	
	

}