package com.sams.entities;

public class AmbulanceDistances implements Comparable<AmbulanceDistances>{
	
	private float distance;
	private ambulance ambulance;
	public AmbulanceDistances() {
		super();
		
	}
	public AmbulanceDistances(float distance, com.sams.entities.ambulance ambulance) {
		super();
		this.distance = distance;
		this.ambulance = ambulance;
	}
	public float getDistance() {
		return distance;
	}
	public void setDistance(float distance) {
		this.distance = distance;
	}
	public ambulance getambulance() {
		return ambulance;
	}
	public void setAmbulance(ambulance ambulance) {
		this.ambulance = ambulance;
	}
	@Override
	public String toString() {
		return "AmbulanceDistances [distance=" + distance + ", Ambulance" + ambulance + "]";
	}
	
	@Override
	public int compareTo(AmbulanceDistances o) {
		// TODO Auto-generated method stub
		if(this.distance < o.distance) {
			return -1;
		}else if(this.distance > o.distance) {
			return 1;
		}else {
			return 0;
		}
		
	}
	
		
	

	
	

}
