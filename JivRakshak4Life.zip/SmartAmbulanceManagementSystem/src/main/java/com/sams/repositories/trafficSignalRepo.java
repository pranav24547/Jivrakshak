package com.sams.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


import com.sams.entities.trafficSignal;


@Repository
public interface trafficSignalRepo extends JpaRepository<trafficSignal, Integer>{
     trafficSignal findById(int id);
     
}
