package com.sams.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sams.entities.Patient;
import com.sams.entities.TripReport;
import java.util.List;


@Repository
public interface tripRepo extends JpaRepository<TripReport, Integer> {
	TripReport findByphoneNo(String phoneNo);
	//TripReport findByTripId(int tripId);
	//TripReport findByamb_Id(int id);
	TripReport findByTripId(int id);

}
