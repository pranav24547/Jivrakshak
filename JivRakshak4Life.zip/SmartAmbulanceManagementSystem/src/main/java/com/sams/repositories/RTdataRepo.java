package com.sams.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sams.entities.RTdata;

@Repository
public interface RTdataRepo extends JpaRepository<RTdata, Integer>{
	RTdata findByAmbId(int id);

}
