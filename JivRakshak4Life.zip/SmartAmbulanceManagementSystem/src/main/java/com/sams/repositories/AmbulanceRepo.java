package com.sams.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sams.entities.ambulance;
import java.util.List;



@Repository
public interface AmbulanceRepo extends JpaRepository<ambulance, Integer>{
 //ambulance findAllbyStatus(Boolean status);
	ambulance findById(float id);
	 List<ambulance> findByStatus(String status);
	 

}
