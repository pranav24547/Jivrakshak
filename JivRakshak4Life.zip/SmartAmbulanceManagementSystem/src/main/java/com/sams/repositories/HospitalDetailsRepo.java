package com.sams.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sams.entities.AmbulanceDetails;
import com.sams.entities.HospitalDetails;
@Repository
public interface HospitalDetailsRepo extends JpaRepository<HospitalDetails, Integer>{


	 HospitalDetails findByhosId(int hosId);

}