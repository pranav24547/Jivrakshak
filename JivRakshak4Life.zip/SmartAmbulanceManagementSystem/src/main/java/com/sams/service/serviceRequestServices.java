package com.sams.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sams.entities.AmbulanceDetails;
import com.sams.entities.AmbulanceDistances;
import com.sams.entities.HospitalDetails;
import com.sams.entities.HospitalDistances;
import com.sams.entities.Patient;
import com.sams.entities.TripReport;
import com.sams.entities.User;
import com.sams.entities.ambulance;
import com.sams.entities.hospital;
import com.sams.repositories.AmbulanceDetailsRepo;
import com.sams.repositories.AmbulanceRepo;
import com.sams.repositories.HospitalDetailsRepo;
import com.sams.repositories.HospitalRepo;
import com.sams.repositories.patientRepo;
import com.sams.repositories.tripRepo;
import com.sams.repositories.userRepo;

@Service
public class serviceRequestServices {

	@Autowired
	private userRepo UserRepo;

	@Autowired
	private patientRepo PatientRepo;

	@Autowired
	private tripRepo TripRepo;

	@Autowired
	private AmbulanceDetailsRepo ambulanceDetailsRepo;
	
	@Autowired
	private HospitalDetailsRepo hospitalDetailsRepo;
	
	@Autowired
	private AmbulanceRepo ambulanceRepo;
	@Autowired
	private HospitalRepo hospitalRepo;
	@Autowired
	private AssignHospitalAndAmbulance assignHA;

	public String saveUser(User user) {
		Patient patient = user.getPatient();
		try {
			Patient Patientsave = PatientRepo.save(patient);
			user.setPatient(Patientsave);
			ArrayList<HospitalDistances> listHospital = assignHA.assignHospital(
					Double.parseDouble(user.getPatient().getLatitude()),
					Double.parseDouble(user.getPatient().getLongitude()));
			ArrayList<AmbulanceDistances> listAmbulances = assignHA.assignAmbulance(
					Double.parseDouble(user.getPatient().getLatitude()),
					Double.parseDouble(user.getPatient().getLongitude()));
			AmbulanceDistances assignedAmbulance = listAmbulances.get(0);
			HospitalDistances assignedHospital = listHospital.get(0);

			TripReport tripReport = new TripReport();
			tripReport.setHospitalDistances(assignedHospital.getDistance());
			tripReport.setAmbulanceDistances(assignedAmbulance.getDistance());
			tripReport.setHospital(assignedHospital.getHospital());
			tripReport.setAmbulance(assignedAmbulance.getambulance());
			tripReport.setPhoneNo(user.getPhoneNo());
			tripReport.setAmb_id(assignedAmbulance.getambulance().getId());
			tripReport.setStatus("Active");
			assignedAmbulance.getambulance().setStatus("Active");
			
			TripReport SaveTripReport = TripRepo.save(tripReport);
			user.setTripReport(SaveTripReport);
			
			int ambId = assignedAmbulance.getambulance().getId();
			System.out.println(ambId);
			AmbulanceDetails AmDetails = ambulanceDetailsRepo.findByambId(ambId);	
			
			if (AmDetails != null) {
			    List<hospital> hospitals = AmDetails.getHospitals();
			    if (!hospitals.contains(assignedHospital.getHospital())) {
			        hospitals.add(assignedHospital.getHospital());
			    }
			    AmDetails.setHospitals(hospitals);

			    List<Patient> patients = AmDetails.getPatients();
			    if (!patients.contains(Patientsave)) {
			        patients.add(Patientsave);
			    }
			    AmDetails.setPatients(patients);

			    ambulanceDetailsRepo.save(AmDetails);
			}
			
			
			int hosid = assignedHospital.getHospital().getHospitalID();
			System.out.println(hosid);
			HospitalDetails hosDetails = hospitalDetailsRepo.findByhosId(hosid);
			
			if (hosDetails != null) {
			    List<ambulance> ambulances = hosDetails.getAmbulances();
			    if (!ambulances.contains(assignedAmbulance.getambulance())) {
			        ambulances.add(assignedAmbulance.getambulance());
			    }
			    hosDetails.setAmbulances(ambulances);

			    List<Patient> HosPatients = hosDetails.getPatients();
			    if (HosPatients.contains(Patientsave)==false) {
			        HosPatients.add(Patientsave);
			    }
			    hosDetails.setPatients(HosPatients);

			    hospitalDetailsRepo.save(hosDetails);
			}

			User Usersave = UserRepo.save(user);
			if (Usersave != null) {

				return "User saved";
			}
		}
		 catch (Exception e) {
			e.printStackTrace();
			return "exception in adding new user";

		}

		return "process terminated";

	}

	public String updateUser(User user) {

		User findByphoneNo = UserRepo.findByphoneNo(user.getPhoneNo());
		if(findByphoneNo.getTripReport().getStatus()=="Active") {
			return "Previous Trip Still Active";
			
		}
		try {
			

			
			
			user.setId(findByphoneNo.getId());
			Patient patient = findByphoneNo.getPatient();
			user.getPatient().setServiceID(patient.getServiceID());
			Patient patient1 = PatientRepo.save(user.getPatient());
			user.setPatient(patient1);
			User save = UserRepo.save(user);
			if (save != null) {
				ArrayList<HospitalDistances> listHospital = assignHA.assignHospital(
						Double.parseDouble(save.getPatient().getLatitude()),
						Double.parseDouble(save.getPatient().getLongitude()));
				ArrayList<AmbulanceDistances> listAmbulances = assignHA.assignAmbulance(
						Double.parseDouble(save.getPatient().getLatitude()),
						Double.parseDouble(save.getPatient().getLongitude()));
				HospitalDistances assignedHospital = listHospital.get(0);
				AmbulanceDistances assignedAmbulance = listAmbulances.get(0);
				TripReport tripReport = new TripReport();
				tripReport.setHospitalDistances(listHospital.get(0).getDistance());
				tripReport.setAmbulanceDistances(listAmbulances.get(0).getDistance());
				tripReport.setHospital(listHospital.get(0).getHospital());
				tripReport.setAmbulance(listAmbulances.get(0).getambulance());
				tripReport.setPhoneNo(save.getPhoneNo());
				tripReport.setStatus("Active");
				assignedAmbulance.getambulance().setStatus("Active");
				TripRepo. save(tripReport);
				
				save.setTripReport(tripReport);
				
				
				int ambId = assignedAmbulance.getambulance().getId();
				System.out.println(ambId);
				AmbulanceDetails AmDetails = ambulanceDetailsRepo.findByambId(ambId);

				if (AmDetails != null) {
				    List<hospital> hospitals = AmDetails.getHospitals();
				    if (!hospitals.contains(assignedHospital.getHospital())) {
				        hospitals.add(assignedHospital.getHospital());
				    }
				    AmDetails.setHospitals(hospitals);

				    List<Patient> patients = AmDetails.getPatients();
				    if (!patients.contains(patient1)) {
				        patients.add(patient1);
				    }
				    AmDetails.setPatients(patients);

				    ambulanceDetailsRepo.save(AmDetails);
				}
				
				int hosid = assignedHospital.getHospital().getHospitalID();
				System.out.println(hosid);
				HospitalDetails hosDetails = hospitalDetailsRepo.findByhosId(hosid);

				if (hosDetails != null) {
				    List<ambulance> ambulances = hosDetails.getAmbulances();
				    if (!ambulances.contains(assignedAmbulance.getambulance())) {
				        ambulances.add(assignedAmbulance.getambulance());
				    }
				    hosDetails.setAmbulances(ambulances);

				    List<Patient> HosPatients = hosDetails.getPatients();
				    if (!HosPatients.contains(patient1)) {
				        HosPatients.add(patient1);
				    }
				    hosDetails.setPatients(HosPatients);

				    hospitalDetailsRepo.save(hosDetails);
				}
				

				User savei = UserRepo.save(save);
				System.out.println(savei);

				return "User updated";
			}
		} catch (Exception e) {
			e.printStackTrace();
			return "exception in updating user";

		}

		return "process terminated";
	}

	public Boolean checkNumber(String phoneNo) {

		try {

			User findByphoneNo = UserRepo.findByphoneNo(phoneNo);
			if (findByphoneNo != null) {
				System.out.println(findByphoneNo.toString());
				return true;
			}

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return false;

	}

	public User getData(String phoneNo) {
		User getData = new User();
		try {

			getData = UserRepo.findByphoneNo(phoneNo);
			System.out.println(getData);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return getData;
	}

	public AmbulanceDetails addAmbulanceDetails(AmbulanceDetails Adm) {
		System.out.println(Adm.toString());

		ambulance ambulance = Adm.getAmbulance();
		ambulance save2 = ambulanceRepo.save(ambulance);
		Adm.setAmbulance(save2);
		Adm.setAmbId(save2.getId());  
		Adm.setHospitals(new ArrayList<hospital>());
		Adm.setPatients(new ArrayList<Patient>());
		AmbulanceDetails save = ambulanceDetailsRepo.save(Adm);
		return save;
	}
	public AmbulanceDetails getAmbulanceDetails(int id) {
		AmbulanceDetails findByambId = ambulanceDetailsRepo.findByambId(id) ;
		return findByambId;
	}

 	public HospitalDetails addHospitalDetails(HospitalDetails Adm) {
		System.out.println(Adm.toString());

		hospital hospital = Adm.getHospital();
		hospital save2 = hospitalRepo.save(hospital);
		Adm.setHospital(save2);
		Adm.setHosId(save2.getHospitalID());  
		Adm.setAmbulances(new ArrayList<ambulance>());
		Adm.setPatients(new ArrayList<Patient>());
		HospitalDetails save = hospitalDetailsRepo.save(Adm);
		return save;
	}
	public HospitalDetails getHospitalDetails(int id) {
		HospitalDetails findByambId = hospitalDetailsRepo.findByhosId(id);
		return findByambId;
	}
	
	public String Endtrip(String PhoneNo) {
		
		User user = UserRepo.findByphoneNo(PhoneNo);
		TripReport data= TripRepo.findByTripId(user.getTripReport().getTripId());
		data.setStatus("Completed");
		
		TripRepo.save(data);
		   int Aid = (int) data.getAmbulance().getId(); 
		int Hid= data.getHospital().getHospitalID();
		hospital Hos= data.getHospital();
		ambulance amb = data.getAmbulance();
	
		ambulance ambulance = ambulanceRepo.findById(Aid);
		if (ambulance != null) {
		    ambulance.setStatus("Completed");
		    ambulanceRepo.save(ambulance);

		    // Rest of your code...
		} else {
		    // Handle the case where ambulance is null
		    return "Ambulance not found for ID: " + Aid;
		}
		
		AmbulanceDetails AmDetails = ambulanceDetailsRepo.findByambId(Aid);
		
		List<hospital> hList = AmDetails.getHospitals() ;
		hList.clear();
		AmDetails.setHospitals(hList);
		
		
		List<Patient> pList = AmDetails.getPatients();
		pList.clear();
		AmDetails.setPatients(pList);
		
		ambulanceDetailsRepo.save(AmDetails);
		
		HospitalDetails HosDetails = hospitalDetailsRepo.findByhosId(Hid);
		List<ambulance> Alist = HosDetails.getAmbulances();
		Alist.remove(amb);
		List<Patient> Plist2 = HosDetails.getPatients();
		Plist2.remove(user.getPatient());
		
		hospitalDetailsRepo.save(HosDetails);
		
		return "Trip stopped";
		
		
	}
	
	public String EndTripByTripId(int tripId) {
	    
	    TripReport data = TripRepo.findByTripId(tripId);
	    
	    if (data == null) {
	        return "Trip not found for ID: " + tripId;
	    }
	    
	    data.setStatus("Completed");
	    TripRepo.save(data);
	    
	    int aid = (int) data.getAmbulance().getId();
	    int hid = data.getHospital().getHospitalID();
	    
	    ambulance ambulance = ambulanceRepo.findById(aid);
	    if (ambulance != null) {
	        ambulance.setStatus("Completed");
	        ambulanceRepo.save(ambulance);
	    } else {
	        return "Ambulance not found for ID: " + aid;
	    }
	    
	    AmbulanceDetails ambulanceDetails = ambulanceDetailsRepo.findByambId(aid);
	    
	    if (ambulanceDetails != null) {
	        ambulanceDetails.getHospitals().clear();
	        ambulanceDetails.getPatients().clear();
	        ambulanceDetailsRepo.save(ambulanceDetails);
	    }
	    
	    HospitalDetails hospitalDetails = hospitalDetailsRepo.findByhosId(hid);
	    
	    if (hospitalDetails != null) {
	        hospitalDetails.getAmbulances().clear();
	        hospitalDetails.getPatients().clear();
	        hospitalDetailsRepo.save(hospitalDetails);
	    }
	    
	    return "Trip ended for Trip ID: " + tripId;
	}

	
	
}
