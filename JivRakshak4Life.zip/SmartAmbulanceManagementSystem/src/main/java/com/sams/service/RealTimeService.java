package com.sams.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sams.entities.RTdata;
import com.sams.entities.ambulance;
import com.sams.entities.trafficSignal;
import com.sams.repositories.HospitalRepo;
import com.sams.repositories.RTdataRepo;
import com.sams.repositories.trafficSignalRepo;

@Service
public class RealTimeService {
	@Autowired 
	private RTdataRepo rTdataRepo;
	@Autowired
	private HospitalRepo hospitalRepo;
	@Autowired
	private trafficSignalRepo repo;
	@Autowired
	private GeofensingService geofensingService;
	
	
	public String setData(RTdata rTdata) {
	try {
		
		RTdata foundByAmbId = rTdataRepo.findByAmbId(rTdata.getAmbId());
		if(foundByAmbId != null) {
			
		//	foundByAmbId.setAmbId(rTdata.getAmbId());
			
			foundByAmbId.setBloodPressure(rTdata.getBloodPressure());
			foundByAmbId.setLatitude1(rTdata.getLatitude1());
			foundByAmbId.setLongitude1(rTdata.getLongitude1());
			foundByAmbId.setPulseRate(rTdata.getPulseRate());
			rTdataRepo.save(foundByAmbId);
			
			
			double lat = Double.parseDouble(rTdata.getLatitude1());
			
		    double lng = Double.parseDouble(rTdata.getLongitude1());
			
		    boolean express1 = geofensingService.isWithinLane1(lat, lng);
		    boolean express2 = geofensingService.isWithinLane2(lat, lng);
		    boolean express3 = geofensingService.isWithinLane3(lat, lng);
		    boolean express4 = geofensingService.isWithinLane4(lat, lng);
			   trafficSignal save = repo.findById(1);
			   save.setLane1(express1);
			   save.setLane2(express2);
			   save.setLane3(express3);
			   save.setLane4(express4);
			   repo.save(save);
			   
			   return "Data Updated";
			   
		}
		else {
			
			rTdataRepo.save(rTdata);
			double lat = Double.parseDouble(rTdata.getLatitude1());
		    double lng = Double.parseDouble(rTdata.getLongitude1());
			
		    boolean express1 = geofensingService.isWithinLane1(lat, lng);
		    boolean express2 = geofensingService.isWithinLane2(lat, lng);
		    boolean express3 = geofensingService.isWithinLane3(lat, lng);
		    boolean express4 = geofensingService.isWithinLane4(lat, lng);
			   trafficSignal save = repo.findById(1);
			   save.setLane1(express1);
			   save.setLane2(express2);
			   save.setLane3(express3);
			   save.setLane4(express4);
			   repo.save(save);
			   
			return "new data added";
			
		}
		
	} catch (Exception e) {
		return e.toString();
	}	
	
	}
	
	public RTdata getData(int id) {

	RTdata rTdata = rTdataRepo.findByAmbId(id);
	return rTdata;
	}
	
	public String addSignal(trafficSignal signal) {
		repo.save(signal);
		return "added";
	}
	
	public trafficSignal getSignalDetails(int id) {
		trafficSignal update= repo.findById(id);
		return update;
	}
	

}
