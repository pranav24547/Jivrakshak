package com.sams.service;

import com.google.maps.GeoApiContext;
import com.google.maps.model.Bounds;
import com.google.maps.model.LatLng;
import org.springframework.stereotype.Service;
@Service
public class GeofensingService {

    private final GeoApiContext geoApiContext;

    public GeofensingService() {
        this.geoApiContext = new GeoApiContext.Builder()
                .apiKey("YOUR_API_KEY")
                .build();
    }

    public boolean isWithinLane1(double lat, double lng) {
        return isWithinBounds(lat, lng, SW_LAT1, SW_LNG1, NE_LAT1, NE_LNG1);
    }

    public boolean isWithinLane2(double lat, double lng) {
        return isWithinBounds(lat, lng, SW_LAT2, SW_LNG2, NE_LAT2, NE_LNG2);
    }

    public boolean isWithinLane3(double lat, double lng) {
        return isWithinBounds(lat, lng, SW_LAT3, SW_LNG3, NE_LAT3, NE_LNG3);
    }

    public boolean isWithinLane4(double lat, double lng) {
        return isWithinBounds(lat, lng, SW_LAT4, SW_LNG4, NE_LAT4, NE_LNG4);
    }

    private boolean isWithinBounds(double lat, double lng, double swLat, double swLng, double neLat, double neLng) {
        boolean isLatWithinBounds = lat >= swLat && lat <= neLat;
        boolean isLngWithinBounds = lng >= swLng && lng <= neLng;
        return isLatWithinBounds && isLngWithinBounds;
    }

    // Constants for each lane's SW and NE bounds
    private static final double SW_LAT1 = 11.00833535882651;
    private static final double SW_LNG1 = 76.98098638065579;
    private static final double NE_LAT1 = 11.01193093013346;
    private static final double NE_LNG1 = 76.98307165231469;

    private static final double SW_LAT2 = 11.01318353064399;
    private static final double SW_LNG2 = 76.98183163900009;
    private static final double NE_LAT2 = 11.015555307154399;
    private static final double NE_LNG2 = 76.98465518234994;

    private static final double SW_LAT3 = 11.0138841593613;
    private static final double SW_LNG3 = 76.9877723479274;
    private static final double NE_LAT3 = 11.015588278626955;
    private static final double NE_LNG3 = 76.98859778399242;

    private static final double SW_LAT4 = 11.009086531788103;
    private static final double SW_LNG4 = 76.98819002622245;
    private static final double NE_LAT4 = 11.01141701335255;
    private static final double NE_LNG4 = 76.98867184885877;
}
