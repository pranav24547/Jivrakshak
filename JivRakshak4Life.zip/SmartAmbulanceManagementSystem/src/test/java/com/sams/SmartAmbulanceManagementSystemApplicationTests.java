package com.sams;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartAmbulanceManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
